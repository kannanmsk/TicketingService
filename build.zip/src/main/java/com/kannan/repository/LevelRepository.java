package com.kannan.repository;

import com.kannan.model.Level;

import java.util.List;
import java.util.Optional;

public interface LevelRepository {

    void add(Level level);

    List<Level> getAll();

    Optional<Level> get(int levelId);
}
