package com.kannan.repository;

import com.kannan.model.Level;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class InMemoryLevelRepository implements LevelRepository {
    private Map<Integer, Level> levels = new HashMap<>();

    @Override
    public void add(Level level) {
        levels.put(level.getLevelId(), level);
    }

    @Override
    public List<Level> getAll() {
        return new ArrayList<>(levels.values());
    }

    @Override
    public Optional<Level> get(int levelId) {
        return Optional.of(levels.get(levelId));
    }
}
