package com.kannan.service;

import org.springframework.stereotype.Component;

@Component
public class SeatHolderService {

    public void releaseSeats() {

    }
}
