package com.kannan.service;

import com.kannan.model.SeatHold;
import com.kannan.repository.LevelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class TicketServiceImpl implements TicketService {
    private LevelRepository levelRepository;
    private SeatHolderService seatHolderService;

    @Autowired
    public TicketServiceImpl(LevelRepository levelRepository, SeatHolderService seatHolderService) {
        this.levelRepository = levelRepository;
        this.seatHolderService = seatHolderService;
    }

    @Override
    public int numSeatsAvailable(Optional<Integer> venueLevel) {
        return 0;
    }

    @Override
    public SeatHold findAndHoldSeats(int numSeats, Optional<Integer> minLevel, Optional<Integer> maxLevel, String customerEmail) {
        return null;
    }

    @Override
    public String reserveSeats(int seatHoldId, String customerEmail) {
        return null;
    }
}
