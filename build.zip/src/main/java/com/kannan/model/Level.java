package com.kannan.model;

public class Level {
    private int levelId;
    private String levelName;
    private double price;
    private int numRows;
    private int seatsInRow;
    private int availableSeats;

    public Level(int levelId, String levelName, double price, int rows, int seatsInRow) {
        this.levelId = levelId;
        this.levelName = levelName;
        this.price = price;
        this.numRows = rows;
        this.seatsInRow = seatsInRow;
    }

    public int getLevelId() {
        return levelId;
    }

    public String getLevelName() {
        return levelName;
    }

    public double getPrice() {
        return price;
    }

    public int getNumRows() {
        return numRows;
    }

    public int getSeatsInRow() {
        return seatsInRow;
    }
}
