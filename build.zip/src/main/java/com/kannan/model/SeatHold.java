package com.kannan.model;

import org.joda.time.DateTime;

public class SeatHold {
    private int seatHoldId;
    private int levelId;
    private String customerEmail;
    private int numSeats;
    private DateTime heldSince;

    public SeatHold(int levelId, String customerEmail, int numSeats, DateTime heldSince) {
        this.levelId = levelId;
        this.customerEmail = customerEmail;
        this.numSeats = numSeats;
        this.heldSince = heldSince;
    }
}
